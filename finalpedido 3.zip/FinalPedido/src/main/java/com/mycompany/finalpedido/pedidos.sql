CREATE TABLE pedidos(
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    comida VARCHAR(100),
    cantidad INT,
    total DECIMAL(10,2)
);