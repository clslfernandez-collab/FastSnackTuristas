/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalpedido;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *
 * @author JIAME
 */
public class Conexion {
    public static Connection conectar() {

        try {

            return DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/pedidodomicilio",
                "root",
                ""
            );

        } catch (SQLException e) {

            return null;

        }

    }
    
}
