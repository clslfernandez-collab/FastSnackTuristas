/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.finalpedido;

/**
 *
 * @author JIAME
 */
public class FinalPedido {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
