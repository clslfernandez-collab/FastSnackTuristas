/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fastsnack.appfastsnack;

/**
 *
 * @author User
 */
public class Cliente extends Persona  implements Acceso{
 
   
    private String direccion;
 
    public Cliente(String nombre, String telefono, String direccion) {
        super(nombre, telefono);
        this.direccion = direccion;
    }
 
    public String getDireccion() {
        return direccion;
    }
 
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
@Override
    public void accederCliente() {
        System.out.println("Cliente accediendo...");
    }


 
}