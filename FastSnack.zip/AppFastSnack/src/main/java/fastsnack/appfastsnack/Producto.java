/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fastsnack.appfastsnack;

/**
 *
 * @author User
 */
public class Producto {
    private String nombre;
    private String precio;
 
    public String getNombre() {
        return nombre;
    }
 
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
 
    public String getPrecio() {
        return precio;
    }
 
    public void setPrecio(String precio) {
        this.precio = precio;
    }
}
