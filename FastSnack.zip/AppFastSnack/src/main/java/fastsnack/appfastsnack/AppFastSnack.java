/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package fastsnack.appfastsnack;

/**
 *
 * @author User
 */
public class AppFastSnack {
    public static void main(String[] args) {
        System.out.println("Hello World!");
        Cliente cliente = new Cliente("dayanna", "0987725752", "la joya");
        cliente.accederCliente();
        Empleado empleado= new Empleado ("dayanna", "03994525687");
        empleado.accederCliente();
    }

}