/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fastsnack.appfastsnack;

/**
 *
 * @author User
 */
public class Pedido {
    private Cliente cliente;
    private String productos;
    private String estado;
    private String fecha;

 
    public Pedido(String productos, String estado, String fecha, String cliente) {
        this.productos = productos;
        this.estado = estado;
        this.fecha = fecha;
    }
 
    public String getProductos() {
        return productos;
    }
 
    public void setProductos(String productos) {
        this.productos = productos;
    }
 
    public String getEstado() {
        return estado;
    }
    public double calcularTotal () {
        return 1;
    }
    public void setEstado(String estado) {
        this.estado = estado;
    }
 
    public String getFecha() {
        return fecha;
    }
 
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
 
    public Cliente getCliente() {
        return cliente;
    }
 
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
 
 
  
}