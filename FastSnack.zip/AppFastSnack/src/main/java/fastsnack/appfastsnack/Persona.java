/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fastsnack.appfastsnack;

/**
 *
 * @author User
 */
public abstract class Persona implements Acceso {
 
    String nombre;
    private String telefono;
     public Persona(String nombre, String telefono) {
        this.nombre = nombre;
        this.telefono = telefono;
    }
 
    @Override
     public abstract void accederCliente();
}